#!/usr/bin/env bash
set -euo pipefail

CONTAINER_NAME="${CONTAINER_NAME:-h1_camera_pipeline}"

echo "============================================================"
echo " SIM 4: START REALSENSE TWO-STAGE IK RETARGET"
echo "============================================================"
echo "CONTAINER_NAME: $CONTAINER_NAME"
echo "INPUT:          /pose/landmarks"
echo "OUTPUT:         /upper_body/command_geom"
echo "ROS_DOMAIN_ID:  42"
echo "============================================================"

for i in $(seq 1 60); do
  if docker ps --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; then
    break
  fi

  if [ "$i" -eq 60 ]; then
    echo "ERROR: container is not running: $CONTAINER_NAME"
    exit 1
  fi

  sleep 1
done

docker exec -it "$CONTAINER_NAME" bash -lc '
set -e

cd /workspace

source /opt/ros/humble/setup.bash
source /workspace/install/setup.bash

export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=0

echo "Stopping old retarget processes safely..."
python3 - <<PY
import os
import signal
import subprocess

me = os.getpid()
out = subprocess.check_output(["ps", "-eo", "pid=,comm=,args="], text=True)

targets = [
    "sim_geometric_retarget_old_with_tpose_yaw.py",
    "sim_geometric_retarget_ik2.py",
    "realsense_ik_upper_body_retarget.py",
]

for line in out.splitlines():
    parts = line.strip().split(None, 2)
    if len(parts) < 3:
        continue
    pid_s, comm, args = parts
    pid = int(pid_s)

    if pid == me:
        continue

    if comm.startswith("python") and any(t in args for t in targets):
        print(f"killing pid={pid} args={args}")
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
PY

sleep 1

python3 /workspace/scripts/robot_h1/realsense_ik_upper_body_retarget.py \
  --ros-args \
  -p input_topic:=/pose/landmarks \
  -p output_topic:=/upper_body/command_geom \
  -p calibration_topic:=/upper_body/start_calibration \
  -p calibration_frames:=45 \
  -p max_joint_step:=0.090 \
  -p elbow_max_step:=0.180 \
  -p yaw_max_step:=0.300 \
  -p joint_alpha:=0.45 \
  -p pitch_gain:=1.00 \
  -p invert_pitch_forward_above_shoulder:=true \
  -p invert_yaw_forward_above_shoulder:=true \
  -p invert_fabrik_target_forward_above_shoulder:=true \
  -p elbow_gain:=1.35 \
  -p left_elbow_straight:=1.57 \
  -p right_elbow_straight:=1.57 \
  -p elbow_deadzone_rad:=0.20 \
  -p left_yaw_up:=1.74 \
  -p right_yaw_up:=-1.74 \
  -p left_yaw_down:=-1.30 \
  -p right_yaw_down:=1.30 \
  -p elbow_only_debug:=false \
  -p robot_upper_len:=0.31 \
  -p robot_fore_len:=0.31 \
  -p fabrik_wrist_weight:=1.00 \
  -p fabrik_position_weight:=2.00
'
